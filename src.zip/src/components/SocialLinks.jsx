import { socialLinks } from "../data/content.js";

// Ikon bawaan per id. Memakai currentColor agar warnanya mengikuti CSS.
const ICONS = {
  github: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path
        d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"
        fill="currentColor"
      />
    </svg>
  ),
  linkedin: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path
        d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
        fill="currentColor"
      />
    </svg>
  ),
  whatsapp: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path
        d="M12 3.5a8.5 8.5 0 0 0-7.3 12.9L3.5 20.5l4.2-1.1A8.5 8.5 0 1 0 12 3.5z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinejoin="round"
      />
      <path
        d="M9.3 8.3c.3-.4.7-.4 1-.2l.9 2c.1.3 0 .5-.3.8l-.4.5c.7 1.3 1.7 2.2 3 2.9l.6-.6c.3-.3.5-.3.8-.2l2 .9c.3.1.4.5.1.9-.5 1-1.5 1.5-2.6 1.2-2.9-.7-5.1-2.8-6-5.6-.2-1 .1-1.9.9-2.6z"
        fill="currentColor"
      />
    </svg>
  ),
  email: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <rect x="3" y="5.5" width="18" height="13" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <path
        d="M4 7.5l8 6 8-6"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  ),
  instagram: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <rect x="3.5" y="3.5" width="17" height="17" rx="5" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" />
    </svg>
  ),
  x: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path
        d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"
        fill="currentColor"
      />
    </svg>
  ),
};

// Pilihan ikon: file logo dari content.js (`logo`) → ikon bawaan per id → huruf pertama label.
function SocialIcon({ link }) {
  if (link.logo) {
    return <img className="social__logo" src={link.logo} alt="" loading="lazy" decoding="async" />;
  }
  return ICONS[link.id] ?? <span className="social__initial">{link.label.charAt(0)}</span>;
}

// Satu tombol sosial. Tanpa url, tombol tampil nonaktif (tidak bisa diklik).
function SocialItem({ link }) {
  const className = `social__item social__item--${link.id}`;

  if (!link.url) {
    return (
      <span className={`${className} is-disabled`} aria-disabled="true">
        <SocialIcon link={link} />
        <span>{link.label}</span>
        <span className="sr-only"> (link not set yet)</span>
      </span>
    );
  }

  // Tautan http(s) dibuka di tab baru; mailto: dan lainnya tetap di tab ini
  const external = /^https?:/.test(link.url);
  return (
    <a
      className={className}
      href={link.url}
      {...(external ? { target: "_blank", rel: "noreferrer noopener" } : {})}
    >
      <SocialIcon link={link} />
      <span>{link.label}</span>
    </a>
  );
}

// Daftar tombol sosial di section Contact, diambil dari `socialLinks` di content.js.
export default function SocialLinks() {
  return (
    <nav aria-label="Social media">
      <ul className="social">
        {socialLinks.map((link) => (
          <li key={link.id}>
            <SocialItem link={link} />
          </li>
        ))}
      </ul>
    </nav>
  );
}
